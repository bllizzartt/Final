import React from 'react'

function Input() {
  return (
    <input>Input</input>
  )
}



export default Input